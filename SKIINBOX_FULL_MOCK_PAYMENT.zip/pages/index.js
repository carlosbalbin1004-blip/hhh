
import Skiinbox from '../components/Skiinbox'

export default function Home() {
  return <Skiinbox />
}
