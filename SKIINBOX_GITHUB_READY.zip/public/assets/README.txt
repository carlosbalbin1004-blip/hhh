Replace these placeholder image files with your Drive or CDN image URLs. Filenames referenced in the project:
- hero.jpg
- how-1.jpg
- lookbook-1.jpg ... lookbook-8.jpg

You can either upload real images here or update <img> src to point to your Drive-hosted URLs.
